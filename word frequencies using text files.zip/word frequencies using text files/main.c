/*************************************************
 * Nom : PAKTIAN Waris
 * Date: 16.05.2016
 * Version: 1.5
 * Titre: Serie 14c
 * Description: Text program principale (.c)
 ************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>

//Structure
typedef struct item item;
struct item {
    char * word;
    item * next;
    int count;
};

//Insert function | Sorts as it enters words
void insert(item ** list, char * word) {

    item * entry = malloc(sizeof(item));
    
    entry->word = word;
    entry->count=1;
    entry->next = NULL;
    
    if( (*list) == NULL) {
        *list = entry;
    }
    else {
        item * cur = (*list);
        item * previous = NULL;
        while(cur!=NULL) {
            if( strcmp (cur->word, entry->word) >= 0 ) {
                break;											
            }
            previous = cur;
            cur = cur->next;									
        }
        if (!cur) {
            previous->next = entry;
        }
        else if ( strcmp(cur->word, entry->word) == 0) {		//if word already exists
            cur->count++;										//increment counter
        }
        else {
            entry->next = cur;
            if (previous)
                previous->next =entry;
            else
                *list = entry;
        }
    }
}

//Prints a given list and its frequency.
void print(item * list) {
    while(list) {
		if(list->count==0)											//if item was deleted
    		list = list->next;										//move to next item
    	else {
		    printf("\t%s \t\t: Freq = %d\n",list->word, list->count);	//print word & frequency
		    list = list->next;
        }
    }
    printf("\n");
}

//Reads text file pointer and returns char word.
char * getWord(FILE *fp) {
    char word[100];
    int ch, i=0;

    while(EOF!=(ch=fgetc(fp)) && !isalpha(ch) && (ch != ' ' || ch !=  '\n'));
    if(ch == EOF)
        return NULL;
    do{
        word[i++] = tolower(ch);
    }while(EOF!=(ch=fgetc(fp)) && isalpha(ch) && (ch != ' ' || ch !=  '\n'));

    word[i]='\0';
    return strdup(word);
}

//Search function looks up a word in a given list.
int search(item ** list, char * word) {
	item * entry = malloc(sizeof(item));
    item * cur = (*list);
    entry->word = word;
    entry->next = NULL;	
    bool found = false;
    int x = 0;

	//printf("\nWord being searched : %s \n\n",entry->word);    

    while(cur->next!=NULL) {
		if( strcmp (cur->word, entry->word) >= 0 ){ 			 
		    break;											
		}
		cur = cur->next;
    }
    if(strcmp(cur->word,entry->word)==0){
    	printf("%s \t\t: Freq = %d\n\n",cur->word, cur->count);
    	found = true;
    	x = 1;
   	}
   	if(!found) {
   		//printf("Word not found!\n\n");
   		x = -1;
   	}	
   	return x;
}

//Delete function erases a word from a given list.
void erase(item ** list, char * word) {
	
	item * entry = malloc(sizeof(item));
    item * cur = (*list);
    entry->word = word;
    entry->next = NULL;
    bool found;	

	printf("\nWord to remove : %s \n\n",entry->word);   

    while(cur->next!=NULL) {
		if( strcmp (cur->word, entry->word) >= 0 ){ 			 
		    break;											
		}
		cur = cur->next;
    }
    if(strcmp(cur->word,entry->word)==0){
    	cur->word = "\0";
    	cur->count = 0;
    	found=true;
   	}
   	if(!found)
   		printf("Word not found\n\n");	
   	else 
   		printf("Word '%s' removed!\n\n",entry->word);
}

//Intersect function shows similar words in both lists
item * intersect(item ** list1, item ** list2){
	item * p1 = (*list1);
	item * p2 = (*list2);
	item * newlist = NULL;				//declare new list
	int x;
	
	printf("Common words in list are:\n\n");
	while(p1->next != NULL) {
		x = search(&p2, p1->word);		//search the word in list 2
		if(x==1){
			insert(&newlist, p1->word);	//if found add word to new list
			newlist->count = 1;			//set count to 1
			x = 0;	
		}
		p1 = p1->next;					//move to next element in list 1
	}
	return newlist;						//return list
}	

//Difference function returns a list of words that are in 
//list 1 but not list 2 (swap in main for other way).
item * difference(item ** list1, item ** list2){
	item * p1 = (*list1);
	item * p2 = (*list2);
	item * newlist = NULL;				//declare new list
	int x;
	
	printf("Common words in list are:\n\n");
	while(p1->next != NULL) {
		x = search(&p2, p1->word);		//search the word in list 2
		if(x==-1){
			insert(&newlist, p1->word);	//if found add word to new list
			newlist->count = 1;			//set count to 1
			x = 0;	
		}
		p1 = p1->next;					//move to next element in list 1
	}
	return newlist;						//return list
}	

//Concat function puts both lists together 
//and returns a new one
item * concat(item ** list1, item ** list2){
	item * p1 = (*list1);
	item * p2 = (*list2);
	item * newlist = NULL;			//declare new list
	
	while(p1->next != NULL && p2->next != NULL) {

		insert(&newlist, p1->word);	//if found add word to new list
		insert(&newlist, p2->word);
		p1 = p1->next;				//move ptr to next
		p2 = p2->next;
	}
	return newlist;					//return list
}

//----------------------------------------------------------------------//	
//---------------------------MAIN program-------------------------------//
//----------------------------------------------------------------------//

int main (int argc, char * argv[]) {
	
	FILE *fp, *fp2;
    char file[] 	= "words1.txt";
    char file2[] 	= "words2.txt";
	char *word, *word2;
	char lookup[30]	= "\0";
	char delete[30]	= "\0";
	char add[30] 	= "\0";
	
	int choix,listchoix;
	int x = 0;

    item * list1 	= NULL;
    item * list2 	= NULL;
    item * common 	= NULL;
    item * unique 	= NULL;
    item * conc 	= NULL;

    fp = fopen(file, "r");
    fp2 = fopen(file2, "r");
    
    if (!fp || !fp2) {
        fprintf(stderr, "\nError opening file(s)!");
        exit(EXIT_FAILURE);
    }

    while(word=getWord(fp)){			//Get word from file one 
        insert(&list1, word);			//Insert word into list and sort
    }
    while(word2=getWord(fp2)){			//Get word from file two
        insert(&list2, word2);			//Insert word into list and sort
    }

	do { 
		printf("-----------------");
		printf("\n  MENU\n\n");
		printf("  1: print list\n");
		printf("  2: search\n");
		printf("  3: delete\n");
		printf("  4: insert\n");
		printf("  5: intersect\n");
		printf("  6: difference\n");
		printf("  7: concat\n");
		printf("  0: quit program\n");
		printf("-----------------\n\n");
		scanf("%d",&choix); 
		printf("\n");
		switch(choix) {
			case 0: 
				//quit
				break;
	 		case 1:
				
				printf("List 1 or 2?\n\n");
				scanf("%d",&listchoix); 
				printf("\n");
				switch(listchoix) {
					case 1:
						printf("List 1 : --------------------\n\n");
						print(list1);					//Print list
						break;
					
					case 2:				
						printf("List 2 : --------------------\n\n");
						print(list2);					//Print list
						break;
				}
			
				break;
			case 2:
				//Search
				printf("Enter word to search : ");
				scanf("%s",lookup);
				x = search(&list1,lookup);
				if (x!=1){
					printf("Word not found!\n\n");
				}
				x = 0;
				break;
			case 3:
				//Delete 
				printf("Enter word to delete : ");
				scanf("%s",delete);
				erase(&list1,delete);
				break;
			case 4:
				printf("Enter word to add : ");
				scanf("%s",add);
				insert(&list1,add);
				break;
			case 5:
				//intersect
				common = intersect(&list1,&list2);
				printf("\n\n\n\n\nCommon words :\n\n");
				print(common);
				break;
			case 6:
				//intersect
				unique = difference(&list1,&list2);
				printf("\n\n\n\n\nDifferent words :\n\n");
				print(unique);
				break;
			case 7:
				//concat
				conc = concat(&list1,&list2);
				printf("\n\n\n\n\nConcatinated words :\n\n");
				print(conc);
				break;
		}
	}while(choix != 0);
    
    fclose(fp);fclose(fp2);			//close files
    free(list1); free(list2);		//free mem alloc 
	free(common); free(unique);		//free mem alloc
	free(conc);
    return 0;
}
