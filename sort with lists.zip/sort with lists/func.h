/************************************************
 * Nom : PAKTIAN Waris
 * Date: 18.01.2016
 * Version: 1.0
 * Titre: Trie pile 
 * Description: Trie pile listing fonctions (.h)
 ***********************************************/

typedef struct Element Element;
struct Element
{
    int nombre;
    Element *suivant;
};

typedef struct Pile Pile;
struct Pile
{
    Element *premier;
};

Pile *initialiser();
void empiler(Pile *pile, int nvNombre);
int depiler(Pile *pile);
void printPile(Pile *pile);
int valeurPile(Pile *pile);
void remplirTableau(int MAX, int tableauValeur[MAX]);
void trierInserer(Pile *PileGauche, Pile *PileDroite, int valeur);
