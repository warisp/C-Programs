/************************************************
 * Nom 		: Paktian
 * Prenom 	: Waris
 * Date		: 10.05.2016
 * Titre	: Tri avec piles
 * Description	: Trier les �l�ments d'un tableau
 *              avec des piles.
 ***********************************************/

#include <stdio.h>
#include <stdlib.h>

#include "func.h"

int main(int argc, char *argv[]) {
    
    if (argc <= 1) {
    	printf("\nEntrez # d'elements a l'execution...\n\n");
    }
    
    int MAX = atoi(argv[1]);
    int tableauValeur[MAX];

    remplirTableau(MAX, tableauValeur);

    Pile *PileGauche = initialiser();
    Pile *PileDroite = initialiser();

    int i=0;
    for(i=0;i<MAX;i++) {
        trierInserer(PileGauche, PileDroite, tableauValeur[i]);
    }

    while(valeurPile(PileDroite) != 0) {
        empiler(PileGauche, depiler(PileDroite));
    }

    printf("\nLa pile :\n\n");
    printPile(PileGauche);

    return 0;
}


