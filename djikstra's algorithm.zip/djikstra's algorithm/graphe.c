//////////////////////////////////////////
// Program : Djikstra en C 
// Version : 1.1
// Author  : PAKTIAN Waris 
// Date	   : 20/06/2015
// Last mod: 25/08/2015
// Desc	   : Main Graph file (graphe.c)
//////////////////////////////////////////
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>

#include "graphe.h"

/*----------------------------------------
Function creates new matrix.
@param size of matrix / 
@return matrix. 
------------------------------------------*/
Matrice* creation_matrice(int taille) {

    //Declare pointer and allocate memory.
    Matrice *matrix = malloc(sizeof(Matrice)); 
    
    int i,j,link=0; 
    
    //Allocate memory for 2d table sizeof taille.
    matrix->Mat = malloc(taille * sizeof(matrix->Mat));

    matrix->taille = taille;

		//Allocate memory for all the cells of table.
    for(i=1; i<=taille; i++){
			matrix->Mat[i] = malloc(taille * sizeof((matrix->Mat[i]))); 
    }

    printf("\nEnter 1 if link exists\nEnter 0 if no link exists\n\n");
	
		//Fill the matrix with 1s and 0s.
    for(i=1 ; i <= taille ; i++) {
        for(j=1 ; j <= taille ; j++){
            printf("Link between node %d & %d: ",i,j);
            scanf("%d",&link);
						matrix->Mat[i][j]=link;
        }
    }

    return matrix; // return the matrix.
}

/*----------------------------------------
Function creates new node (point).
@param int j (next point/suivant) / 
@return node. 
------------------------------------------*/
Noeud* creation_noeud(int j) {

		//Declare pointer and allocate memory for a node.
    Noeud* node = malloc(sizeof(Noeud));
		//link neighboring node
    node->voisin = j;
		//Initialise node->next as NULL
    node->suivant = NULL;

    return node; //return the node.
}

/*----------------------------------------
Function converts matrix into graphe.
@param Matrice / 
@return graphe. 
------------------------------------------*/
Graphe* conversion(Matrice* adj) {
    
    int i,j,k=1;
    
		//Memory allocation for graphe.
    Graphe *graphe = malloc(sizeof(Graphe));
		//initialise size of links to 0.
    graphe->taille = 0;
    
		/****** Defines the number of links we need ******/
		//read through matrix and every '1' we encounter we increment taille.
     for (i=1; i<=adj->taille; i++) {
        for (j=1; j<=adj->taille; j++) {
            if (adj->Mat[i][j]==1){
                graphe->taille = graphe->taille+1;
            }
        }
    }
  
 		//Memory allocation for the table of arete 
    graphe->arete = malloc(graphe->taille * sizeof(graphe->arete));

		//read through matrix (adj) and every '1' we encounter we create 
		//a link between the nodes in graphe.
    for (i=1; i<=adj->taille; i++) {
        for (j=1; j<=adj->taille; j++) {
            if (adj->Mat[i][j]==1){
                graphe->arete[k] = malloc(sizeof(Noeud));
                graphe->arete[k]->voisin=i;
                graphe->arete[k]->suivant = creation_noeud(j);
                k++;
            }
        }
    }
		return graphe;
}

/*----------------------------------------
Function creates new link between nodes.
@param graphe, node1, node2 / 
@return graphe. 
------------------------------------------*/
Graphe* inserer(Graphe* g,int s1,int s2) {

    int i;
		//Declaring a node.
    Noeud *node;
		// Declare and allocate memory for temporary graph.
    Graphe *temp = malloc(sizeof(Graphe));
		//Initialise size to 0 
    temp->taille = 0;
		//Boolean to know if link exists
    bool link = false;

    for (i=1;i<=g->taille;i++){
    		//Verify if link exists already between the points by checking neighbors 
        if ((g->arete[i]->voisin==s1) && (g->arete[i]->suivant->voisin==s2)) {
            link = true;
        }
    }

    if (link == true)
        printf("\nLink exists already between %d & %d !\n",s1,s2);
    //if no link exists...
    else {	
				//Enlarge graphe->taille by 1 (arete (link) + 1)
        temp->taille = g->taille+1;
        
				//Allocate memory for arete table in graphe struct					
        temp->arete = malloc(temp->taille * sizeof((g->arete)));
        
				//Copy the graphe into temp 
        for (i=1;i<=g->taille;i++) {
            temp->arete[i] = malloc(sizeof(Noeud));
            temp->arete[i] = g->arete[i];
            
            //If we're on s2, we take the address of s2 in 'node' to make the link 
            if (temp->arete[i]->voisin==s2) {
                node = temp->arete[i]; //if we're on s2, stock s2 in 'node'.     
            }
        }
        
				//Allocate memory for the new cell and we add the link 
        temp->arete[temp->taille] = malloc(sizeof(Noeud));
        temp->arete[temp->taille]->voisin = s1;
       	temp->arete[temp->taille]->suivant = node;

        printf("Link added !\n");
    }

    return temp; //Return new graph.
}

/*----------------------------------------
Function deletes link between nodes.
@param graphe, node1, node2 /  
------------------------------------------*/
void supprimer(Graphe* g,int s1,int s2) {

    int i; 
    bool link = false; 

		//Read through graph, check for link and erase it.
    for (i=1;i<=g->taille;i++){
		  if ((g->arete[i]->voisin==s1) && (g->arete[i]->suivant->voisin==s2)) {
				link = true;
				//Remove neighbor and pointer.
				g->arete[i]->voisin = 0;
				g->arete[i]->suivant = NULL;
				
				printf("\nLink deleted between %d & %d\n",s1,s2);
		  }
    }
		//If no link present...
    if (link == false) printf("\nThere's already no link between %d & %d !\n",s1,s2);
}

/*----------------------------------------
Function for djikstra algorithm
@param graphe, departure node / 
@return shortest path (all links). 
------------------------------------------*/
Etape* dijkstra(Graphe *g,int s) {

    int x,i,j=s; 
    
    int size = g->taille;
    
   	// Declare and allocate memory for table of treated steps.
    int *tab = calloc(size, sizeof(int));
   	// int *tab = malloc(g->taille*sizeof(int));
	
		bool fin; //Boolean to know if all points have been visited.
	
		//Declare and allocate memory for table of type etape
    Etape **tableau = malloc(size*sizeof(Etape));

		//Allocate memory for tab cells and initialise them...
    for(i=1 ; i <= size ; i++){
        tableau[i] = malloc(sizeof(Etape)); //initialise cell of tableau.
        tableau[i]->marque = false;
        tableau[i]->precedent = 0;
        // tab[i] = malloc(sizeof(int)); //tab[i] = 0;
    }
	
		//While all the points haven't been visited
    while (fin == false) {
		
				//We read through (parcour) graphe until the point 'j' (the point of departure)
        for(i=1 ; i <= size ; i++){
		      if (g->arete[i]->voisin==j){ //if we're on the departure node
		
							//We marque the point of departure as visited
		          if (tableau[s]->marque==false){
		              tableau[s]->marque=true;
		          }
		
							//If a link leaves from this point (that hasnt been visited), we follow it and 
							//marque the next point and keeps its previous point 
		          if ((g->arete[i]->suivant!=NULL) && (tableau[g->arete[i]->suivant->voisin]->marque == false)) {
		              tableau[g->arete[i]->suivant->voisin]->precedent = g->arete[i]->voisin;
		              tableau[g->arete[i]->suivant->voisin]->marque = true;
		          }
		       }
        }
		
				//Read through the table of previous and if we find a marked point that 
				//hasn't been treated, we restart the step above using this new point 
				//as a point of departure.
    		for(i=1 ; i <= size ; i++){
          if((tableau[i]->marque==true) && (tab[i+1]!=1)){
              j=i;
              tab[i+1]=1;
              break;
          }
		
					//If we're at the end of the table, we finished everything and can leave the loop.
          if (i==size) {
              fin = true;
          }
        }	
    }

		//Read through 'tableau' and print all marked points and their previous origin. 
    for (i=1; i <= size; i++){
  		//if tableau index in marked and previous isn't 0
      if ((tableau[i]->marque==true) && (tableau[i]->precedent != 0)) { 
				printf("[%d] -> %d\n\n",tableau[i]->precedent,i);
      }
    }
}

/*----------------------------------------
Function prints matrix
@param Matrice /  
------------------------------------------*/
void print_matrix(Matrice* mat) {

    int i,j;
    
		//Read matrix in loop and print each cell.
    for(i=1 ; i <= mat->taille ; i++) {
        for(j=1 ; j <= mat->taille ; j++){
            printf("	%d ",mat->Mat[i][j]);
        }
        printf("\n \n");
    }
}

/*----------------------------------------
Function prints graphe.
@param graphe / 
------------------------------------------*/
void print_graph(Graphe* graphe){

    int j;
	
		//Read through graph and print each link (neighbor)
    for(j=1 ; j <= graphe->taille ; j++){
        if(graphe->arete[j]->voisin!=0)
            printf("\n%d -> %d \n",	graphe->arete[j]->voisin, 
            												graphe->arete[j]->suivant->voisin);
    }
}
