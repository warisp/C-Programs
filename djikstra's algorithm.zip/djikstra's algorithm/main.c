//////////////////////////////////////////
// Program : Djikstra en C 
// Version : 1.1
// Author  : PAKTIAN Waris 
// Date	   : 20/06/2015
// Last mod: 25/08/2015
// Desc	   : Main file (main.c)
//////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>

#include "graphe.h"

  int i,j,choice;
  int s1,s2,s,nbre=0;
  int end = 0;
  
  Matrice* mat;
  Graphe *graphe;
  Noeud* sommet;

  Etape *path;

  void main(){

    while (end==0) {

      printf("\n=================== \n");
      printf("  Djikstra - Menu \n");
      printf("=================== \n\n");

      printf("1 - Create graph \n");
      printf("2 - Add a link \n");
      printf("3 - Delete a link \n");
      printf("4 - See graph \n");
      printf("5 - Dijkstra \n");
      printf("\n");
      printf("0 - Quit \n\n");
      printf("Choice : ");
      scanf("%d", &choice);

      switch(choice) {
             case 1:
                printf("\nNumber of nodes: ");
                scanf("%d",&nbre);
                mat = creation_matrice(nbre);
                printf("\nMatrix: \n \n");
                print_matrix(mat);
                graphe = conversion(mat);
                break;

             case 2:
                printf("\nFirst node: ");
                scanf("%d",&s1);
                printf("Second node: ");
                scanf("%d",&s2);
                graphe = inserer(graphe,s1,s2);
                break;

             case 3:
                printf("\nFirst node: ");
                scanf("%d",&s1);
                printf("Second node: ");
                scanf("%d",&s2);
                supprimer(graphe,s1,s2);
                break;
             
             case 4:
                printf("\nGraph: \n \n ");
                print_graph(graphe);
                break;

             case 5:
                printf("\nNode to start from: ");
                scanf("%d",&s);
                printf("\n");
                path = dijkstra(graphe,s);
                break;

             case 0:
                end = 1;
                break;

             default:
                printf("\n	Wrong choice !\n");
                break;
          }
    }
  }
