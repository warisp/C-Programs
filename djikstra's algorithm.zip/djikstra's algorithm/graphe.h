#ifndef GRAPHE_H
#define GRAPHE_H

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>


typedef struct Matrice {
   int taille;  //number of points on graph.
   int **Mat;   //2d matrix table
}Matrice;


typedef struct Noeud {
   int voisin;           		//neighboring point
   struct Noeud* suivant;   //pointer on node.
}Noeud;


typedef struct Graphe {
   int taille;  	// number of links between points.
   Noeud **arete;	//1d table of links.
}Graphe;


typedef struct Etape {
   int precedent;  // previous sommet
   bool marque;    // boolean sommet visited
}Etape;


Matrice* creation_matrice(int taille);
Noeud* creation_noeud(int k);
Graphe* conversion(Matrice* adj);

Graphe* inserer(Graphe* g,int s1,int s2);
void supprimer(Graphe* g,int s1,int s2);

Etape* dijkstra(Graphe *g,int s);

void print_matrix(Matrice* mat);
void print_graph(Graphe* graphe);

#endif
