/************************************************
 * Nom 		: Paktian
 * Prenom 	: Waris
 * Date		: 14.04.2016
 * Version	: 1.0
 * Titre	: Probl�me de Joseph
 * Description	: R�soudre le probl�me de Joseph
                � l'aide des listes dynamiques circulaires.
 ***********************************************/

#include <stdio.h>
#include <stdlib.h>

#include "func.h"

int main(int argc, char *argv[]) {
    
    int n = atoi(argv[1]);
    int k = atoi(argv[2]);

    Liste *maListe = initialisation(n, k);

    while (maListe->premier != maListe->dernier) {
        int i;
        for(i=0;i<k-1;i++) {
            maListe->courant = maListe->courant->suivant;
        }

        printf("%d", suppression(maListe));
        printf("\n");
    }
    printf("%d", suppression(maListe));
    printf("\n");

    return 0;
}
