/************************************************
 * Nom 		: PAKTIAN Waris
 * Date		: 14.04.2016
 * Version	: 1.0
 * Titre	: Problème de Joseph
 * Description: Joseph listing fonctions (.h)
 ***********************************************/

typedef struct Element Element;
struct Element
{
    int nombre;
    Element *suivant;
};

typedef struct Liste Liste;
struct Liste
{
    Element *premier;
    Element *dernier;
    Element *courant;
};

Liste *initialisation(int n, int k);
void insertion(Liste *liste, int nvNombre);
int suppression(Liste *liste);
void afficherListe(Liste *liste);
