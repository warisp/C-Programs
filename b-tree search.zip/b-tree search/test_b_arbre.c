//////////////////////////////////////////
// Program : B-Arbre
// Version : 1.2
// Author  : PAKTIAN Waris 
// Date	   : 21/05/2015
// Last mod: 14/06/2015
// Desc	   : Main file (B_arbre.c)
//////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "b_arbre.h"  

int main(int argc, char** argv) {
	
	//Arguement test
	if (argc < 3) {
		printf("Error: More arguments required.\n");
		return -1;
	}
	
	//Variables
	int a,i,j,p,x,val,choix;
	
	int order = atoi(argv[1]);	//Convert 2nd argument to int. 
	const char* d = argv[argc-1];	//store argv[last] in d. (display type)
	const char* display = argv[argc-2]; //stores 'display' parameter.
	const char * d0 = "display"; //printf("%s\n",d0);
	const char * d1 = "RGD";
	const char * d2 = "GRD";
	
	Page * tree = new_page(order);	//Create head page.
	
	//Call insert function for arguments 
	for (x = 2; x<argc-2; x++){
		a = atoi(argv[x]);
		inserer(tree,a);	
	}
	
	if ((strcmp(display,d0))==0) {		//if display is typed correctly.
	
		//if RGD call disp(RGD)
		if (strcmp(d1,d)==0) {
			printf("Display Racine-Gauche-Droite:\n");
			display_RGD(tree,0,-1);
		}
	
		//if GRD call disp(GRD)
		if (strcmp(d2,d)==0) {
			printf("Display Gauche-Racine-Droite\n");
			display_GRD(tree);
		}
		
	} else {
		printf("False parameter\n");
	}
	
	return 0;
}
