	/*
	//DDD test
	Page * tree = new_page(2);
	inserer(tree,2);
	inserer(tree,3);
	inserer(tree,1);
	inserer(tree,4);
	inserer(tree,5);
	printf("Done!\n");
	*/

	///////////////////////////////////////////////	
	//	Menu
	///////////////////////////////////////////////
	/*
	while(1) {

    printf("\nB-Tree							\n\n");
    printf("Options : \n");
    printf("0 = Quit \n");
    printf("1 = Insert keys\n");
    printf("2 = Display tree\n");
    
		scanf("%d", &choix);
	
    switch(choix){
    	case 0:
	  		exit(1);
	   		break;
    	
    	case 1:

      printf("How many values to enter : ");
      scanf("%d",&p);

      for(j=0; j<p; j++) {
        printf("Key #%d :   ",j);
        scanf("%d",&val);
        inserer(tree,val);
        }
        
        break;

      case 2 :
      	display_RGD(tree,0,-1);
	    	printf("\n");
	   		
	   		break;
		}	
	}
	*/
