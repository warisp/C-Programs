
#include <stdlib.h>
#include <stdio.h>

int main(int argc,char** argv) {

	char d = argc[argc+1];

	char one = "display_RGD";
	char two = "display_GRD";
	
	


}
