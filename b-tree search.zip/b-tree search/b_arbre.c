//////////////////////////////////////////
// Program : B-Arbre
// Version : 1.1
// Author  : PAKTIAN Waris 
// Date	   : 21/05/2015
// Desc	   : Main file (B_arbre.c)
//////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "b_arbre.h"  

/*----------------------------------------
Function creates new page.
@param order of tree / 
@return page of type Page. 
------------------------------------------*/
Page* new_page(int order) {
 
  if (order < 1) {	 //order test.
      printf("Error: order < 1!!\n");
      return NULL;
  }

  int size = order * 2 + 1;	//+2 for tmp case

  Page* page_to_create;

  page_to_create = malloc(sizeof(Page));
  page_to_create->nb = 0;
  page_to_create->pg_0 = NULL;
  page_to_create->order = order;

  page_to_create->tab = calloc(size, sizeof(Element));	//allocates memory for an array

  return page_to_create;
}

/*----------------------------------------
Function finds position of key in tree.
@param tree, key 
@return i of type int. 
------------------------------------------*/
int position(Page* pg, int clef) {
		
	int i = 0;

    while( 	( i <= pg->nb ) && 
    		( pg->tab[i].clef != 0 ) && 
    		( pg->tab[i].clef < clef ) ){
        
        i++;
    }
    //printf("POS: %d\n",i);
    return i; 
}

/*----------------------------------------
Function places key in tree.
@param tree, cell 
------------------------------------------*/
void placer(Page* pg, Element* cell) {
	
 	int pos = 0;
	int i = 0, j=0;
	Page* page2;
	
	int ord = pg->order;
	
	//On trouve la position ou inserer la clef dans la page
	pos = position(pg,cell->clef);

	for ( i = pg->nb-1; i >= pos; i--) {
	  pg->tab[i+1]=pg->tab[i];
	}

	pg->nb++;//incremente counter in page
	pg->tab[pos].clef=cell->clef;
	pg->tab[pos].pg=cell->pg;//insert the key into the table cell
		
	//if we pass 2 times the order in a tab
	//create a new page containing the keys of order + 2 till 2*order
	if ( pg->nb > 2*ord ){		

		page2 = new_page(ord);		
		i=0;
		j=0;
		for ( i = ord+1; i <= 2*ord; i++ ) {
		  page2->tab[j]=pg->tab[i];
		  pg->tab[i].pg = NULL;
		  pg->tab[i].clef = 0;
		  j++;//counter 

		}
		//Promote the middle value to the superior tab
		page2->pg_0 = pg->tab[ord].pg;
		page2->nb = j;

		cell->pg = page2;
		cell->clef = pg->tab[ord].clef;
		pg->nb = ord;
		pg->tab[ord].pg = NULL;
		pg->tab[ord].clef = 0;
	} else{	
      cell->pg = NULL;	//otherwise cell.pg is set to NULL
    }
}

/*----------------------------------------
Function inserts cell into tree
@param tree, cell 
------------------------------------------*/
Page* inserer_case(Page* b_arbre, Element* cell){
	
	int pos,i;
	
    pos = position(b_arbre,cell->clef);

	if ( cell->pg == NULL){
		if(pos==0){							//if we place in index 0
			if ( b_arbre->pg_0 == NULL ){   //if page is empty. 
				placer(b_arbre,cell);			//place at index 0
			}else{								
				inserer_case(b_arbre->pg_0,cell);
				if ( cell->pg != NULL){   					//cell.pg != NULL
					placer(b_arbre,cell);
				}
			}	
		}else{
			if ( b_arbre->tab[pos-1].pg == NULL ){
				placer(b_arbre,cell);
			}else{
				inserer_case(b_arbre->tab[pos-1].pg,cell);	
				if ( cell->pg != NULL){   					//cell.pg != NULL
					placer(b_arbre,cell);
				}
			}
		}
	}  
}

/*----------------------------------------
Main insert function, uses inserer_case
@param tree, key
------------------------------------------*/
Page* inserer(Page* b_arbre,int clef){
    Element* cell;
    Page* page0;
    int i, ordre = b_arbre->order;
    
    cell=malloc(sizeof(cell));
    cell->clef = clef;
    cell->pg = NULL;

    inserer_case(b_arbre,cell );

   //Creation of new page at level 0 (Sommet)
    if ( cell->pg != NULL ) {
        page0 = new_page(ordre);

        page0->nb = b_arbre->nb;
        page0->pg_0 = b_arbre->pg_0;
        //Assignment of the key in the new page 0
        for (i =0; i < ordre*2+1; i++) {
            page0->tab[i].clef = b_arbre->tab[i].clef;
            page0->tab[i].pg = b_arbre->tab[i].pg;
            b_arbre->tab[i].clef = 0;
            b_arbre->tab[i].pg = NULL;
        }

        b_arbre->nb = 1;
        b_arbre->pg_0 = page0;
        b_arbre->tab[0].clef=cell->clef;
        b_arbre->tab[0].pg=cell->pg;

    }
}

/*----------------------------------------
Function displays tree in RGD form
@param tree, tree level, cell 
@return prints tree in console
------------------------------------------*/
void display_RGD ( Page* b_arbre, int level, int key ){
	int i,j,x;
	int next_level;
	next_level = level+1;
	j=0;

	//printf("\n\tPage nb: %d\n", b_arbre->nb );	//Print nb of elements in each page. 
	printf("\n");
	while ( b_arbre->tab[j].clef!=0){
		for (x=0;x<=level;x++) {
			printf("\t");	
		}
		printf(/*"Lvl: %d | Sup_key: %d | Key: */"%d\n",/* level,key,*/b_arbre->tab[j].clef );
  	j++;
	}

	j=0;
	if ( b_arbre->pg_0 !=NULL ){
		display_RGD( b_arbre->pg_0, next_level, b_arbre->tab[j].clef );
	}
	while ( b_arbre->tab[j].clef!=0){
		if ( b_arbre->tab[j].pg !=NULL ){
			display_RGD( b_arbre->tab[j].pg, next_level, b_arbre->tab[j].clef );
		}
		j++;
	}
}

void display_GRD (Page* b_arbre) {
	printf("GRD\n");
}

