#ifndef _B_ARBRE_
#define _BARBRE_
#include <math.h>
#include <stdio.h>

//Structures
typedef struct Element {
	int clef;						//info stockee
	struct Page* pg;		//ptr sur une page
}Element;

typedef struct Page {
	int order;					//ordre de la page
	int nb;							//compteur de cles dans la page
	Element *tab;				//tab dans la page
	struct Page* pg_0;  //Pointeur sur la page enfant tout à gauche
}Page;

//Headers
Page* new_page (int ordre);

int position(Page* pg, int clef);
void placer(Page* pg, Element* cell);
Page* inserer_case(Page* b_arbre, Element* cell);
Page* inserer(Page* b_arbre,int clef);

void display_RGD( Page* b_arbre, int level, int key );
void display_GRD (Page* b_arbre);

#endif
