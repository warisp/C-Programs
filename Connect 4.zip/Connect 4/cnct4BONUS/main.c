//////////////////////////////////////////
// Program : Puissance 4
// Version : 1.4
// Author  : PAKTIAN Waris 
// Date	   : 10/01/2015
// Desc	   : Functions file (func.c)
//////////////////////////////////////////
#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "func.h"

#define BOARD_ROWS 6
#define BOARD_COLS 7

int main(int argc, char *argv[]){

	int choix;

	do { 
	
		const char *PIECES = "XO";						//constant char for pieces.
		
		char board[BOARD_ROWS * BOARD_COLS];	//table of char (2d col * row).

		memset(board, ' ', sizeof board);			//creates empty table sizeof board.

		int turn, done = 0;
		int totalCell = BOARD_ROWS * BOARD_COLS;

		puts("\n    ****Connect Four****");
		fprintf(stderr,"\nMENU\n\n");
		fprintf(stderr,"0: Quit program\n");
		fprintf(stderr,"1: Player vs Player\n");
		fprintf(stderr,"2: Player vs Computer\n\n");

		scanf("%d:",&choix); 	// !!!Ne pas modifier!!!

		switch(choix) {
			case 0:				
				//quitter
			break;
		case 1: 

			for(turn = 0; turn < totalCell && !done; turn++){
				printBoard(board);   

				while(!takeTurn(board, turn % 2, PIECES)){
					printBoard(board);   
					printf("**Column full!**\n");
				}

				done = checkWin(board);
			} 
			printBoard(board);

			if(turn == totalCell && !done){			//if all cells are filled and no one won
				printf("It's a tie!");						//game's a tie.
			} else {
				turn--;
				printf("Player %d (%c) wins!\n", turn % 2 + 1, PIECES[turn % 2]);
			}           
		    break;
		
		case 2: 

			for(turn = 0; turn < totalCell && !done; turn++){
				printBoard(board);   

				while(!takeTurnPC(board, turn % 2, PIECES)){
					printBoard(board);   
					printf("**Column full!**\n");
				}
				done = checkWin(board);
			} 
			
			printBoard(board);

			if(turn == totalCell && !done){			//if all cells are filled and no one won
				printf("It's a tie!");						//game's a tie.
			} else {
				turn--;
				if (turn % 2 == 0) 
					printf("Player %d (%c) wins!\n", turn % 2 + 1, PIECES[turn % 2]);
				else if (turn % 2 == 1) 
					printf("Computer wins :(\n");
			}           
		    break;
		}
	
	}while(choix != 0);

	return 0;
}

