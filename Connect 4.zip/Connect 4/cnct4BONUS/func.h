//////////////////////////////////////////
// Program : Puissance 4
// Version : 1.4
// Author  : PAKTIAN Waris 
// Date	   : 10/01/2015
// Desc	   : Header file (func.h)
//////////////////////////////////////////
#include <stdio.h>
#include <string.h>

void printBoard(char *board);
int takeTurn(char *board, int player, const char*);
int takeTurnPC(char *board, int player, const char *PIECES);
int checkWin(char *board);
int checkFour(char *board, int, int, int, int);

int check3(char *board, int a, int b, int c);

int horizontalCheck(char *board);
int verticalCheck(char *board);
int diagonalCheck(char *board);
