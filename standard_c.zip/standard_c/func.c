/************************************************
 * Nom : PAKTIAN Waris
 * Date: 18.01.2016
 * Version: 1.0
 * Titre: Calendrier
 * Description: Calendrier fichier fonctions
 ***********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "func.h"


