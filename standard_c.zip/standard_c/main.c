/*************************************************
 * Nom : PAKTIAN Waris
 * Date: 18.01.2016
 * Version: 1.0
 * Titre: Calendrier
 * Description: Calendrier program principale (.c)
 ************************************************/

#include <stdio.h>	//standard in/out
#include <stdlib.h>	//standard library
#include <stdbool.h>//boolean function
#include <string.h> //memset function

#include "func.h"		//functions file

int main(int argc, char *argv[]) {

    printf("\nHello world!\n");

    return 0;
}
