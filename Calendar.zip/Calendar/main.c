/*************************************************
 * Nom : PAKTIAN Waris
 * Date: 18.01.2016
 * Version: 1.0
 * Titre: Calendrier
 * Description: Calendrier program principale (.c)
 ************************************************/

#include <stdio.h>	//standard in/out
#include <stdlib.h>	//standard library
#include <stdbool.h>//boolean function
#include <string.h> //memset function

#include "func.h"		//functions file

int main(int argc, char *argv[]) {

    const int NBR_SEMAINES_MAX = 6;
    int NBR_JOURS_SEMAINE = 7;

    int annee, mois, nbrSemaines;

    int calendrier[NBR_SEMAINES_MAX][NBR_JOURS_SEMAINE];  //déclare notre calendrier
		memset(calendrier, 0, sizeof calendrier);							//initialisation du calendrier
    
    annee = atoi(argv[1]);		//atoi transforms string argv[#] to integer
    mois = atoi(argv[2]);
    printf("\n\tAnnee : %d\n\tMois  : %d",annee,mois);

    nbrSemaines = doCal(annee, mois, NBR_SEMAINES_MAX, NBR_JOURS_SEMAINE, calendrier);
    printCal(nbrSemaines, NBR_SEMAINES_MAX, NBR_JOURS_SEMAINE, calendrier);

    return 0;
}
