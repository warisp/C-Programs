/************************************************
 * Nom : PAKTIAN Waris
 * Date: 18.01.2016
 * Version: 1.0
 * Titre: Calendrier
 * Description: Calendrier listing fonctions (.h)
 ***********************************************/

typedef enum T_Jour_Semaine T_Jour_Semaine;
typedef enum T_mois T_mois;

enum T_Jour_Semaine {Lu, Ma, Me, Je, Ve, Sa, Di};
enum T_mois {Jan, Fev, Mar, Avr, Mai, Jun, Jui, Aou, Sep, Oct, Nov, Dec};

int estBissextile(int annee);
int nbJoursMois(int annee, T_mois mois);
T_Jour_Semaine premierJourAnnee(int annee);
T_Jour_Semaine premierJourMois(int annee, T_mois mois);
int nbSemaines(int annee, T_mois mois, int premJourMois);
int doCal(int annee, T_mois mois, int NBR_SEMAINES_MAX, int NBR_JOURS_SEMAINE, int calendrier[NBR_SEMAINES_MAX][NBR_JOURS_SEMAINE]);
void printCal(int nbrSemaines, const int NBR_SEMAINES_MAX, int NBR_JOURS_SEMAINE, int calendrier[NBR_SEMAINES_MAX][NBR_JOURS_SEMAINE]);
