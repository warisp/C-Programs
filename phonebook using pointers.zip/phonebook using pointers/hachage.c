//////////////////////////////////////////
// Program 	: Annuaire (phonebook app)
// Version 	: 1.4
// Author  	: PAKTIAN Waris 
// Date 	: 30/03/2015
// Desc		: Functions (hachage.c +.h)
//////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "hachage.h"

// LOAD function loads up the file and hashes the names in every line.
annuaire * loadFile(char* filename, annuaire* table_hash) {
   int SizeTab,j;
   //int valname;
   annuaire student;
   char line[80];
   FILE *fp;
   fp = fopen(filename, "r+");
   char tab;
   int line_cnt=0;

    while ((fgets(line,80,fp)) != NULL) {
        line_cnt++;
    }

    fseek(fp,0,SEEK_SET); //equivalent to rewind(fp);

    SizeTab=countlinetab(line_cnt);
    table_hash=creatTab(SizeTab);

    while ((fgets(line,80,fp)) != NULL ) { //While not end of file, parse info and *insert*.
        char *ptr = line;
        int nb_car;
        sscanf(ptr,"%80[^;]%n",student.nom,&nb_car);
        ptr += nb_car+1;
        sscanf(ptr,"%80[^;]%n",student.classe,&nb_car);
        ptr += nb_car+1;
        sscanf(ptr,"%d",&student.tel);
        //printf("%s;%s;%d\n",student.nom,student.classe,student.tel);
        //printf("%d",15);
        unsigned int valhash = hash(student.nom);
        
        insert(student.nom,student.classe,student.tel,valhash, table_hash);
    }

   fclose(fp);
   afficheTab(table_hash);
   
   newline();
   printf("%d",line_cnt);
   newline();	

   return table_hash;
}

//Function defines the number of lines for malloc.
int countlinetab(int line_cnt) {
	int nbr_line;
	nbr_line=line_cnt * 1.5;
	while (!prime(nbr_line)) {
		nbr_line++;
	}
	return nbr_line;
}

//Function returns a prime number.
int prime(int Nombre) {
	int i = 1;
	int test = 1;
	
	if(Nombre % 2 == 0)
		return 0;
	else {
		for(i=3; i < (int)(sqrt(Nombre) +1); i=i+2) {
			if(Nombre % i == 0)
			test = 0;
		}
	}
	return test;
}

//Function to create table.
annuaire * creatTab(int nbr_line) {
    annuaire* table_hash = (annuaire*) malloc(nbr_line * sizeof(annuaire));
    return table_hash;
}

//HASHING functions.
int hash(char* name) {
    int numname , i=0;

    unsigned int valname;
    while (name[i] != 0) {
        numname += name[i];
        i++;
    }
    valname = numname % 151;
    return valname;
}
//HASH2 takes lenght of string
int hash2(char* name) {
    int saut = strlen(name);
    return saut;
}

//Function in case of collision.
int collision (char* name, annuaire* table_hash, unsigned int valhash) {
    //int hash1;
    //hash1=hash(name);
    while (table_hash[valhash].etat == OCCUPE) {
        valhash= (valhash + hash2(name))%151;
    }
    return valhash;
}

//INSERT function using string copy.
int insert(char* name, char* classe, int* num, unsigned int valhash, annuaire* table_hash) {

    while (table_hash[valhash].etat == OCCUPE) {
        valhash= collision(name, table_hash, valhash);
    }
    strcpy (table_hash[valhash].nom, name);
    strcpy (table_hash[valhash].classe, classe);
    table_hash[valhash].tel=num;
    table_hash[valhash].etat = OCCUPE;

    return valhash;
}

//Functions to show table
void afficheTab(annuaire* table_hash) {
	for (int i=0;i<151;i++) {
		if (table_hash[i].etat == OCCUPE) {
            printf("%d | %s;%s;%d\n",i,table_hash[i].nom,table_hash[i].classe,table_hash[i].tel);
        }
    }
}

//SEARCH function
void recherche(char* name, annuaire* table_hash) {
    int valname;
    valname=hash(name);
    int flag = 0;
    
      
    while (flag==0) {
    	if(table_hash[valname].etat == SUPPRIMER){flag=3;}
        else if ((strcmp(table_hash[valname].nom,name))==0){flag=1;}
		else if(table_hash[valname].etat != OCCUPE){flag=2;}
        else{
			valname+=hash2(name);
        }
    }

    if (flag == 1){
        printf("\n	%s;%s;%d\n",table_hash[valname].nom,table_hash[valname].classe,table_hash[valname].tel);
    }
    else if (flag == 2) {
        printf("-1\n");
    }
    else if (flag == 3) {
    	printf("Person '%s' was deleted.",name);
    	newline();
    }
}

//INSERT function.
void insertPerson(char* name, char* classe, int num, annuaire* table_hash) {
	int valhash=hash(name);

	while (table_hash[valhash].etat == OCCUPE) {
		valhash= collision(name, table_hash, valhash);
	}
	
	strcpy (table_hash[valhash].nom, name);
	strcpy (table_hash[valhash].classe, classe);
	table_hash[valhash].tel=num;
	table_hash[valhash].etat = OCCUPE;
}

//DELETE function from table_hash
void SupprPerson(char* name, annuaire* table_hash) {
    int valname=hash(name);
    int flag = 0;

	while (flag==0) {
		if ((strcmp(table_hash[valname].nom,name))==0) {flag=1;}
		else{
			valname+=hash2(name);
		}
	}
    if (flag == 1) {
        table_hash[valname].etat=SUPPRIMER;
    }
    printf("Person '%s' was deleted.",name);
    newline();
}

//SAVE function.
void saveInFile(annuaire *table_hash) {
	FILE *fp;
	int nb=0;
	//Check filename to be output.txt
	if((fp = fopen("output.txt", "w+")) == NULL) {
		perror("database.txt");
		exit(EXIT_FAILURE);
	}
	
	for(int i=0;i<151;i++) {
		if (table_hash[i].etat==OCCUPE && table_hash[i].etat!=LIBRE) {
			fprintf(fp,"%s;%s;%d\n",table_hash[i].nom,table_hash[i].classe,table_hash[i].tel);
			nb++;
		}
	}	
	fclose(fp);
	printf("\n	%d",nb);
}

/*---------------------MISC procedures---------------------*/
//newline function.
void newline(void) {
	printf("\n");
}

//Nb of people in Struct."annuaire".
void taux (annuaire* table_hash) {
    int i, ln = 0;
    short nb = 0;
    for (int i=0;i<151;i++) {
        if (table_hash[i].etat == OCCUPE) {
           nb++;
        }
    	ln++;
    }
    //int ln = line_ctr(filename);
    printf("\n	%d | %d", nb, ln);
    newline();
}

//Line counter function. Currently UNUSED
int line_ctr (char* filename) {
	FILE *fp = fopen(filename, "r+");
	char line[80];
	int line_cnt=0;

	while ((fgets(line,80,fp)) != NULL) {
		line_cnt++;
	}
	return line_cnt;
}

