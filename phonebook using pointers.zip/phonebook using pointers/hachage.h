#ifndef _HACHAGE_H_
#define _HACHAGE_H_
#include <math.h>
#include <stdio.h>

// Structure de donnée
enum typeetat {
   LIBRE,
   OCCUPE,
   SUPPRIMER
};

typedef struct annuaire {
   char nom[80];
   char classe[4];
   int  tel;
   enum typeetat etat;
} annuaire;

annuaire * creatTab(int nbr_line);

/*FUNCTIONS*/
annuaire * loadFile(char* filename, annuaire* table_hash);
int prime(int Nombre);
int hash(char* name);
int collision (char* name, annuaire* table_hash, unsigned int valhash);
int insert(char* name, char* classe, int* tel, unsigned int valhash, annuaire* table_hash);
int line_ctr (char* filename);

/* PROCEDURES */
void afficheTab(annuaire* table_hash);
void recherche(char* name, annuaire* table_hash);
void SupprPerson(char* name, annuaire* table_hash);
void taux (annuaire* table_hash);
void saveInFile(annuaire *table_hash);
void newline(void);

#endif
