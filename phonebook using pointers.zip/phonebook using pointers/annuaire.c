//////////////////////////////////////////
// Program : Annuaire (phonebook app)
// Version : 1.4
// Author  : PAKTIAN Waris 
// Date	   : 30/03/2015
// Desc	   : Main file (annuaire.c)
//////////////////////////////////////////

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "hachage.h"  
#define STR_SIZE 80

int main(int argc,char** argv) {

   annuaire* table_hash;

   FILE* input = stdin;
   if (argc > 1) {
   	if ((input = fopen(argv[1],"r+")) == NULL) {
		   fprintf(stderr,"File not found");
		   return 1;
	   }
	}
   int choix;
   do { // !!!Ne pas modifier le menu!!!
      fprintf(stderr,"\nMENU\n\n");
      fprintf(stderr,"0: quitter\n");
      fprintf(stderr,"1: charger un fichier\n");
      fprintf(stderr,"2: sauver dans un fichier\n");
      fprintf(stderr,"3: inserer une personne (nom;classe;telephone)\n");
      fprintf(stderr,"4: rechercher par nom\n");
      fprintf(stderr,"5: rechercher par telephone\n");
      fprintf(stderr,"6: supprimer par nom\n");
      fprintf(stderr,"7: supprimer par telephone\n");
      fprintf(stderr,"8: imprimer tout l'annuaire\n");
      fprintf(stderr,"9: remplissage de l'annuaire\n");
      fprintf(stderr,"Entrez votre choix:\n");

      char nom[STR_SIZE];
      char classe[4];
      int tel;
      char filename[STR_SIZE];
      char line[STR_SIZE];

      fscanf(input,"%d:",&choix); // !!!Ne pas modifier!!!
      switch(choix) {
         case 0: //quitter
            /* Entree clavier <0:> */
            break;
         case 1: //loadFile un fichier
            /* Entree clavier <1: filename>
             * (Exemple) 1: etudiants.txt
             */
            fscanf(input,"%s",filename);              // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour loadFile le fichier <filename>
             * Sortie ecran <nombre de lignes lues dans le fichier>
             */
			annuaire* table_hash = loadFile(filename, table_hash);
            break;
         case 2: //sauver dans un fichier
            /* Entree clavier <2: filename>
             * (Exemple) 2: sortie.txt
             */
            fscanf(input,"%s",filename);              // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour sauver dans le fichier <filename>
             * Sortie ecran <nombre de lignes écrites dans le fichier>
             */
            saveInFile(table_hash);
            newline();
            //printf("103\n");                         // !!!Respecter le format!!!
            break;
         case 3: //inserer une personne
            /* Entree clavier <3: nom;classe;tel>
             * (Exemple) 3: Michel Deriaz;IT4;9234567
             */
            fgets(line,STR_SIZE,input);               // !!!Ne pas modifier!!!
            int nb_car;                               // !!!Ne pas modifier!!!
            char* ptr = line;                         // !!!Ne pas modifier!!!
            sscanf(ptr," %80[^;]%n",nom,&nb_car);     // !!!Ne pas modifier!!!
            ptr += nb_car+1;                          // !!!Ne pas modifier!!!
            sscanf(ptr,"%80[^;]%n",classe,&nb_car);   // !!!Ne pas modifier!!!
            ptr += nb_car+1;                          // !!!Ne pas modifier!!!
            sscanf(ptr,"%d",&tel);                    // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour inserer <nom>, <classe> <tel>
             * dans l'annuaire
             * Pas de sortie ecran
             */
            int valhash=hash(nom); 	//This is done to print initial index 
            						//actual hashing of name in *insert*
            int nb = insert(nom, classe, tel, valhash, table_hash);
            printf("\nHash %d | %d | %s\n",valhash, nb,nom);
            newline();
            //printf("%d | %s;%s;%d",valhash,nom,classe,tel); 
            //afficheTab(table_hash[valhash]); 
            break;
         case 4: //rechercher par nom
            /* Entree clavier <4: nom>
             * (Exemple) 4: Mathieu Landru
             */
            fgets(line,STR_SIZE,input);               // !!!Ne pas modifier!!!
            sscanf(line," %80[^\n]",nom);             // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour rechercher <nom> dans l'annuaire
             * Sortie ecran <nom;classe;tel>
             */
            recherche(nom, table_hash);
            //printf("Mathieu Landru;IT1;3458127\n");   // !!!Respecter le format!!!
            break;
         case 5: //rechercher par telephone
            /* Entree clavier <5: tel>
             * (Exemple) 5: 3458127
             */
            fscanf(input,"%d",&tel);                  // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour rechercher <tel> dans l'annuaire
             * Sortie ecran
             *
             *              <nom1;classe1;tel>
             *              <nom2;classe2;tel>
             *              <nom3;classe3;tel>
             *              ....
             */
            printf("4\n"); // nombre d'elements avec ce numero de telephon
            break;
         case 6: //supprimer par nom
            /* Entree clavier <6: nom>
             * (Exemple) 6: Mathieu Landru
             */
            fgets(line,STR_SIZE,input);               // !!!Ne pas modifier!!!
            sscanf(line," %80[^;]",nom);              // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour supprimer <nom> dans l'annuaire
             * Pas de sortie ecran
             */
            SupprPerson(nom,table_hash);
            break;
         case 7: //supprimer par telephone
            /* Entree clavier <7: tel>
             * (Exemple) 7: 3458127
             */
            fscanf(input,"%d",&tel);                  // !!!Ne pas modifier!!!
            /* Appel de votre fonction pour supprimer <tel> dans l'annuaire
             * Pas de sortie ecran
             */
            break;
         case 8: //imprimer tout l'annuaire
            /* Entree clavier <8:> */
            /* Appel de votre fonction pour imprimer l'annuaire
             * Sortie ecran
             *              <nom1;classe1;tel>
             *              <nom2;classe2;tel>
             *              <nom3;classe3;tel>
             *              ....
             */
             
            afficheTab(table_hash);
            break;
         case 9: //remplissage de l'annuaire
            /* Entree clavier <9:> */
            /* Appel de votre fonction pour le remplissage de l'annuaire
             * Sortie ecran <nombre d'elements> et <taille> de la table de hachage
             */
             taux(table_hash);                 
             break;
      }
   }while(choix != 0);
   fclose(input);
   return 0;
}
